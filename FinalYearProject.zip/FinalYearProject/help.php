
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Online Banking Service</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="signupstylesheet.css" rel="stylesheet">
  </head>

  <body>
    <div class="container">






<div class="content">







</div>

<div class="footer">
<p>footer</p>
</div>

</div>

  </body>
</html>
