<?php
if ( ($_POST['name']!="")){
$name = $_POST['name'];

echo "<p>'.$name.'</p>";
}
?>